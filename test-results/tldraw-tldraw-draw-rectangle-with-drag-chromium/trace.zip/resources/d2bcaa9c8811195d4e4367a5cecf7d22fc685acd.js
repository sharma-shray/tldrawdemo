
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof self?self:{},n=(new Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="380c7e3b-88f5-59b2-96c1-c3d4aa4688ba")}catch(e){}}();
const y=()=>"tldraw-tldraw-2025-07-10/WyJocTUxVWM3RiIsWyIqLnRsZHJhdy5jb20iXSw5LCIyMDI1LTA3LTEwIl0.fcGEICPNGbpCjxyLkyRXjv7CfcenRjBRl06I/v6loCD8CijVePhVwsT3B+TgJr+x7ihZAa/cn6N43ty6yz/ZPg";export{y as g};
//# sourceMappingURL=license-TXA9olDC.js.map

//# debugId=380c7e3b-88f5-59b2-96c1-c3d4aa4688ba
