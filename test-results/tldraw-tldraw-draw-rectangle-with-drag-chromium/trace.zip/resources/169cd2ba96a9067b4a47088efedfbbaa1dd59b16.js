
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="41160e84-6f98-5019-aa88-45ae877455eb")}catch(e){}}();
const t="/api/unfurl",o="https://assets.tldraw.xyz",s="https://images.tldraw.xyz",a=typeof location<"u"?`${window.location.origin}/api`:"https://sync.tldraw.xyz".replace(/^http/,"ws"),n=typeof location<"u"?"https://production.zero.tldraw.com/":"http://localhost:4848/";export{o as A,t as B,s as I,a as M,n as Z};
//# sourceMappingURL=config-DrSeUO7w.js.map

//# debugId=41160e84-6f98-5019-aa88-45ae877455eb
