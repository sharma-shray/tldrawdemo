
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="702dfd3f-89ac-57a0-91b9-7149afe4c8c1")}catch(e){}}();
import{ap as a,h as c,aq as s}from"./index-BIrMIDk6.js";import{B as i}from"./config-DrSeUO7w.js";async function d({url:t}){const o=a(t);try{const e=i+"?"+new URLSearchParams({url:t}).toString(),r=await(await c(e,{method:"POST"})).json();return{id:s.createId(o),typeName:"asset",type:"bookmark",props:{src:t,description:(r==null?void 0:r.description)??"",image:(r==null?void 0:r.image)??"",favicon:(r==null?void 0:r.favicon)??"",title:(r==null?void 0:r.title)??""},meta:{}}}catch(e){return console.error(e),{id:s.createId(o),typeName:"asset",type:"bookmark",props:{src:t,description:"",image:"",favicon:"",title:""},meta:{}}}}export{d as c};
//# sourceMappingURL=createAssetFromUrl-DGynJqL2.js.map

//# debugId=702dfd3f-89ac-57a0-91b9-7149afe4c8c1
