(function() {
  window._POSTHOG_REMOTE_CONFIG = window._POSTHOG_REMOTE_CONFIG || {};
  window._POSTHOG_REMOTE_CONFIG['phc_i8oKgMzgV38sn3GfjswW9mevQ3gFlo7bJXekZFeDN6'] = {
    config: {"token": "phc_i8oKgMzgV38sn3GfjswW9mevQ3gFlo7bJXekZFeDN6", "supportedCompression": ["gzip", "gzip-js"], "hasFeatureFlags": false, "captureDeadClicks": false, "capturePerformance": {"network_timing": true, "web_vitals": true, "web_vitals_allowed_metrics": null}, "autocapture_opt_out": true, "autocaptureExceptions": false, "analytics": {"endpoint": "/i/v0/e/"}, "elementsChainAsString": true, "sessionRecording": false, "heatmaps": false, "surveys": false, "defaultIdentifiedOnly": true},
    siteApps: []
  }
})();