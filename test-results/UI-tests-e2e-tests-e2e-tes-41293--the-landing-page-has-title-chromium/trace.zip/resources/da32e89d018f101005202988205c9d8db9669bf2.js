(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_pages_index_5771e1._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_pages_index_5771e1._.js",
  "chunks": [
    "static/chunks/node_modules_next_b9a53c._.js",
    "static/chunks/node_modules_react-dom_82bb97._.js",
    "static/chunks/node_modules_@mui_material_0f4609._.js",
    "static/chunks/node_modules_@mui_system_esm_11e0bd._.js",
    "static/chunks/node_modules_@mui_x-date-pickers_13d113._.js",
    "static/chunks/node_modules_@popperjs_core_lib_515829._.js",
    "static/chunks/node_modules_b7a86a._.js",
    "static/chunks/[root of the server]__6d3001._.js"
  ],
  "source": "entry"
});
